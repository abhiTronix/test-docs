import React from 'react';
import '../App.css';
const NavBar = () => {
  return (
    <div>
      <div className="navbar">
        <a className="active" href='/'> BlockChain Voting System</a>
      </div>
      <br />
      <hr />
    </div>
  )
}

export default NavBar